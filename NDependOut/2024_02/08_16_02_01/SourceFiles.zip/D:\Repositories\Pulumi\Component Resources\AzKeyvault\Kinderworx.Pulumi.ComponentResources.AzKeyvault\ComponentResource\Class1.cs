﻿namespace ComponentResource
{
    public class Class1
    {

    }
}
